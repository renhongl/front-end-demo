

import view from './views/app';

export { view };
