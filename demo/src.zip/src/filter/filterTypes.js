

export default  {
    SHOW_ALL: '全部',
    SHOW_COMPELETED: '完成',
    SHOW_UNCOMPELETED: '未完成'
};