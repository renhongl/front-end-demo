

import reducer from './reducer';
import actions from './actions';
import view from './views/filterCont';

export { reducer, actions, view };