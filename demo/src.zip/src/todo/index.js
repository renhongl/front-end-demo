

import reducer from './reducer';
import actions from './actions';
import view from './views/todoCont';

export { reducer, actions, view };